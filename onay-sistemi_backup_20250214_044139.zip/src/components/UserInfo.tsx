  <div className="text-sm text-gray-500">
    Kredi: {user.credits}
  </div> 